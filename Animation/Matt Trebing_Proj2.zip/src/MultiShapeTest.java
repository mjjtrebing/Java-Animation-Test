/*
 * Matt Trebing
 * 3/28/16
 * MultiShapeTest.java
 */
public class MultiShapeTest
{
	/**
	 * Main method
	 * @param args
	 */
	public static void main(String[] args)
	{
		View v= new View();
		v.frameBuilder();
	}
}